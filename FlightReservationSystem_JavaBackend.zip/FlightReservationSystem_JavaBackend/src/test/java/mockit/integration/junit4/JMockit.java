package mockit.integration.junit4;

public class JMockit {

}
