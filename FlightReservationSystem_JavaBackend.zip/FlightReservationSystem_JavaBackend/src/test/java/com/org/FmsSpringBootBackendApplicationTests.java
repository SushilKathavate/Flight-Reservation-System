package com.org;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.web.WebAppConfiguration;

@SpringBootTest(classes = FmsSpringBootBackendApplication.class)
@WebAppConfiguration
class FmsSpringBootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
