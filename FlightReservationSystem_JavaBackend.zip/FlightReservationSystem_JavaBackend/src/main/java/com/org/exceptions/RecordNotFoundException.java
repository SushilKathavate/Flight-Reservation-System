package com.org.exceptions;

public class RecordNotFoundException extends RuntimeException {

	public RecordNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}
	
}
