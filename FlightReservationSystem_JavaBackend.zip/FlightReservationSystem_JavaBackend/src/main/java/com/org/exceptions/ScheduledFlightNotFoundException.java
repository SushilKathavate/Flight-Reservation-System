package com.org.exceptions;

public class ScheduledFlightNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ScheduledFlightNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}
}
