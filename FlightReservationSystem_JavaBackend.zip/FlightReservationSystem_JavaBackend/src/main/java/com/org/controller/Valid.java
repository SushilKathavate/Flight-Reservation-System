package com.org.controller;

public @interface Valid {

}
