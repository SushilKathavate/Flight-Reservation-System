package com.org.model;

public @interface Size {

	int min();

	int max();

}
