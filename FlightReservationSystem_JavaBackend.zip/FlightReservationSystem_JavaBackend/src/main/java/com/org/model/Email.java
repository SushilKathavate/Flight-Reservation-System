package com.org.model;

public @interface Email {

}
