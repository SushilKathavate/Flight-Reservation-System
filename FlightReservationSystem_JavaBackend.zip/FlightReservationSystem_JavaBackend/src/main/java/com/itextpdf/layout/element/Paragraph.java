package com.itextpdf.layout.element;

public class Paragraph {

	public Paragraph(String string) {
		// TODO Auto-generated constructor stub
	}

}
