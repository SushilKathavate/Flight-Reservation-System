package com.itextpdf.layout;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.element.Paragraph;

public class Document {

	public Document(PdfDocument pdf) {
		// TODO Auto-generated constructor stub
	}

	public void close() {
		// TODO Auto-generated method stub
		
	}

	public void add(Paragraph paragraph) {
		// TODO Auto-generated method stub
		
	}

}
