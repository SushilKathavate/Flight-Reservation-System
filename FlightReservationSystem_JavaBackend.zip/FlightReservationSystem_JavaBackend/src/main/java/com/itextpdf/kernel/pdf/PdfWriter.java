package com.itextpdf.kernel.pdf;

public class PdfWriter {

	public PdfWriter(String filePath) {
		// TODO Auto-generated constructor stub
	}

}
